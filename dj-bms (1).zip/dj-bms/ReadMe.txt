Assumptions: No assumptions.

Reasoning behind the choice of implementation: I love Django :)

How to run server?

1. create a virtualenv and activate it
  on linux/macosx:
    # install virtualenv
	pip3 install virtualenv
	# create a virtual environment
	virtualenv venv
	# activate venv
	source venv/bin/activate
	
  on windows:
    # install virtualenv
	pip install virtualenv
	# create a virtual environment
	virtualenv venv
	# activate venv
	venv/Scripts/activate
	
2. Install dependencies
	pip install -r requirements.txt
	
3. Make the migrations and collect all static files
    python manage.py makemigrations
	python manage.py migrate
	python manage.py collectstatic

4. Run the server
	python manage.py runserver

