from django.urls import path
from dj_bms_app.views import *

urlpatterns = [
    path('', index, name='index'),
    path('add_book/', add_book, name='add_book'),
    path('edit_book/<int:pk>/', BookUpdate.as_view(), name='edit_book'),
    path('delete_book/<int:pk>/', BookDelete.as_view(), name='delete_book'),
    path('search_book/', search_book, name='search_book'),
]
