from django.shortcuts import render, redirect
from django.core.paginator import Paginator
from django.views.generic import UpdateView, DeleteView
from dj_bms_app.forms import BookForm, BookSearchForm
from dj_bms_app.models import Book
from django.contrib import messages
from django.urls import reverse_lazy
from django.contrib.messages.views import SuccessMessageMixin
from django.conf import settings
import requests


def index(request):
    books = Book.objects.all()
    paginator = Paginator(books, 5)
    page = request.GET.get('page', 1)
    paged_books = paginator.get_page(page)
    return render(request, 'dj_bms_app/index.html', {'books': paged_books})


def add_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST)
        try:
            if form.is_valid():
                form.save()
                messages.success(request, 'Book added successfully.')
                return redirect('index')
        except Exception as e:
            print(e)
            messages.error(request, 'Something went wrong.')
    else:
        form = BookForm()
    return render(request, 'dj_bms_app/book_form.html', {'form': form, 'is_add_book': True})


def search_book(request):
    if request.method == 'POST':
        form = BookSearchForm(request.POST)
        try:
            if form.is_valid():
                title = form.cleaned_data.get('title', '').lower().replace(' ', '+')
                author = form.cleaned_data.get('author', '').lower().replace(' ', '+')
                url = '%s?q=intitle:%s+inauthor:%s' % (settings.GOOGLE_BOOKS_API, title, author)
                print(url)
                response = requests.get(url)
                json_response = response.json()
                if json_response['totalItems'] == 0:
                    ctx = {'form': form, 'books_exists': -1}
                else:
                    books_collection = list()
                    for book in json_response['items']:
                        record = {
                            'book_id': book.get('id'),
                            'title': book['volumeInfo']['title'],
                            'authors': ', '.join(book['volumeInfo']['authors']),
                            'exists': Book.objects.filter(book_id=book.get('id')).exists()
                        }
                        books_collection.append(record)
                    ctx = {'form': form, 'books': books_collection,
                           'books_exists': 1 if len(books_collection) else -1}
                return render(request, 'dj_bms_app/book_search.html', ctx)
        except Exception as e:
            messages.error(request, 'Something went wrong.')
    else:
        form = BookSearchForm()
    return render(request, 'dj_bms_app/book_search.html', {'form': form})


class BookUpdate(SuccessMessageMixin, UpdateView):
    model = Book
    fields = ('book_id', 'title', 'copies_available')
    template_name = 'dj_bms_app/book_form.html'
    success_url = reverse_lazy('index')
    success_message = 'Book record updated successfully.'


class BookDelete(SuccessMessageMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('index')
    success_message = 'Book record deleted successfully.'

    def delete(self, request, *args, **kwargs):
        messages.success(self.request, self.success_message)
        return super(BookDelete, self).delete(request, *args, **kwargs)
