from django import forms
from dj_bms_app.models import Book


class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ('book_id', 'title', 'copies_available')


class BookSearchForm(forms.Form):
    title = forms.CharField(max_length=20, required=False)
    author = forms.CharField(max_length=20, required=False)
