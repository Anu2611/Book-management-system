from django.apps import AppConfig


class DjBmsAppConfig(AppConfig):
    name = 'dj_bms_app'
